from camera import startapplication

startapplication()